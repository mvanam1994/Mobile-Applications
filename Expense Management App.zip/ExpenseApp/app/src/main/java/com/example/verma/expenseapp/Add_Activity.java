package com.example.verma.expenseapp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class Add_Activity extends AppCompatActivity implements View.OnClickListener {
    private ArrayList<Expense> arrayList;
    private static final int SELECT_IMAGE = 1;
    EditText dateText;
    Spinner category_spinner;
    String date;
    String image_path="";
    String name;
    Double amount;
    String category;
    private DatePickerDialog datePickerDialog;

    private SimpleDateFormat dateFormatter;

    static final int DATE_DIALOG_ID = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_);
        dateFormatter = new SimpleDateFormat("MM-dd-yyyy");
        if (getIntent().getExtras() != null) {
            arrayList = (ArrayList) getIntent().getExtras().get(MainActivity.EXPENSELIST_KEY);
        }
        category_spinner = (Spinner) findViewById(R.id.add_category);
        String[] items = new String[]{"Select a Category","Groceries", "Invoice", "Transportation", "Rent", "Trips", "Utilities", "Others"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items);
        category_spinner.setAdapter(adapter);


        ImageView imageView = (ImageView) findViewById(R.id.addActivity_receiptSearch);
        imageView.setOnClickListener(this);


        dateText = (EditText) findViewById(R.id.Edit_addactivity_date);
        dateText.setInputType(InputType.TYPE_NULL);

        imageView =(ImageView) findViewById(R.id.image_addActivity_date);
        imageView.setOnClickListener(this);

        Button button = (Button) findViewById(R.id.add_activity_addexpense);
        button.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.addActivity_receiptSearch:
                Intent gallery = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
                startActivityForResult(gallery, SELECT_IMAGE);
                break;
            case R.id.image_addActivity_date:
                    setDateField();
                    break;

            case R.id.add_activity_addexpense:
                int flag=1;
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                EditText editText = (EditText) findViewById(R.id.Edit_addactivity_name);
                if(editText.getText().toString().length()<=50 && editText.getText().toString().length()>0 ) {
                    name = editText.getText().toString();
                    flag=0;
                }
                else{
                    flag=1;
                    builder.setTitle("Enter Name").setMessage("Name should be entered");
                    AlertDialog alert = builder.create();
                    alert.show();
                }

                editText =(EditText) findViewById(R.id.Edit_addactivity_amount);
                String amount_entered = editText.getText().toString();
                if(amount_entered.equals(null)){
                    flag=1;
                    builder.setTitle("Enter amount").setMessage("Amount should contain Numbers only");
                    AlertDialog alert = builder.create();
                    alert.show();
                }else{
                    amount=Double.parseDouble(amount_entered);
                    flag=0;

                }
                if(image_path.equals("")){
                    flag=1;
                    builder.setTitle("Pic a image").setMessage("Select an image of the receipt");
                    AlertDialog alert = builder.create();
                    alert.show();
                }else{
                    flag=0;
                }
                if(date.equals(null)){
                    flag=1;
                    builder.setTitle("Enter a date").setMessage("Select a Date");
                    AlertDialog alert = builder.create();
                    alert.show();
                }else{
                    flag=0;
                }
                category=category_spinner.getSelectedItem().toString();
                if(category.equals("Select a Category")){
                    flag=1;
                    builder.setTitle("Pic a Category").setMessage("Select a category");
                    AlertDialog alert = builder.create();
                    alert.show();
                }else{
                    flag=0;
                }

                if(flag==0){
                    Expense expense = new Expense(name,category,amount,date,image_path);
                    arrayList.add(expense);
                    Log.d("expense",name+"+"+category+"+"+amount+"+"+date+"+"+image_path);
                    Intent explicitIntent = new Intent(Add_Activity.this,MainActivity.class);
                    explicitIntent.putExtra(MainActivity.ACTION_KEY,MainActivity.ADD_KEY);
                    explicitIntent.putExtra(MainActivity.EXPENSELIST_KEY,arrayList);
                    startActivity(explicitIntent);
                }
                break;

            /*case R.id.add_category:
                category=category_spinner.getSelectedItem().toString();
                break;*/



            default:
                break;
        }
    }


    private void setDateField() {
        Calendar newCalendar = Calendar.getInstance();


            datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    Calendar newDate = Calendar.getInstance();
                    newDate.set(year, monthOfYear, dayOfMonth);
                    dateText.setText(dateFormatter.format(newDate.getTime()));
                    date = dateFormatter.format(newDate.getTime());
                    Log.d("date",date);
                    Log.d("datetext",dateFormatter.format(newDate.getTime()));

                }

            }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));

            datePickerDialog.show();

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode==RESULT_OK && requestCode==SELECT_IMAGE){
            Uri selectedImage=data.getData();
            String path=getPath(selectedImage);
            image_path = path;
            ImageView imageView= (ImageView) findViewById(R.id.addActivity_receiptSearch);
            imageView.setImageURI(selectedImage);
            imageView.getLayoutParams().height = 60;

            imageView.getLayoutParams().width = 60;

            imageView.setScaleType(ImageView.ScaleType.FIT_XY);

        }
    }

    public String getPath(Uri uri){
        String[] filePathColumn={MediaStore.Images.Media.DATA};

        Cursor cursor=getContentResolver().query(uri, filePathColumn, null, null, null);
        cursor.moveToFirst();
        int columnIndex=cursor.getColumnIndex(filePathColumn[0]);

        return cursor.getString(columnIndex);
    }
}

