package com.example.verma.expenseapp;

import java.io.Serializable;

/**
 * Created by verma on 9/11/2016.
 */
public class Expense implements Serializable {

    String name;
    String categories;
    double amount;
    String date;
    String imageURI;

    public Expense(String name, String categories, double amount, String date, String imageURI) {
        this.name = name;
        this.categories = categories;
        this.amount = amount;
        this.date = date;
        this.imageURI = imageURI;
    }

    @Override
    public String toString() {
        return name+"+"+categories+"+"+amount+"+"+date+"+"+imageURI;
    }

    public String getName() {
        return name;
    }

    public String getCategories() {
        return categories;
    }

    public String getDate() {
        return date;
    }

    public double getAmount() {
        return amount;
    }

    public String getImageURI() {
        return imageURI;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCategories(String categories) {
        this.categories = categories;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setImageURI(String imageURI) {
        this.imageURI = imageURI;
    }
}
