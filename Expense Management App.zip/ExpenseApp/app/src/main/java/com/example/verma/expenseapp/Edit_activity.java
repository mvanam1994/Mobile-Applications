package com.example.verma.expenseapp;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Edit_activity extends AppCompatActivity {

    private static final int SELECT_IMAGE = 1;
    private ArrayList<Expense> arrayList;
    Expense selectedElement;
    Button button;
    Button buttonSave;
    Expense expense;
    CharSequence[] cs;
    String name;
    String date;
    String image_path="";
    double amount;
    String category;
    EditText editText;
    ImageView imageView;
    ImageView imageReceipt;
    DatePickerDialog datePickerDialog;
    SimpleDateFormat dateFormatter;
    Spinner category_spinner;
    int element=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_activity);
        if(getIntent().getExtras().containsKey(MainActivity.EXPENSELIST_KEY)){
            arrayList = (ArrayList) getIntent().getExtras().get(MainActivity.EXPENSELIST_KEY);
        }
        dateFormatter = new SimpleDateFormat("MM-dd-yyyy");
        category_spinner = (Spinner) findViewById(R.id.spinner_editcategory);

        imageReceipt = (ImageView) findViewById(R.id.imagereciept_editactivity);
        String[] items = new String[]{"Select a Category","Groceries", "Invoice", "Transportation", "Rent", "Trips", "Utilities", "Others"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items);
        category_spinner.setAdapter(adapter);

        button = (Button) findViewById(R.id.button_selectexpense);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder1= new AlertDialog.Builder(Edit_activity.this);
                builder1.setTitle("Pick an Expense");
                List<String> list = new ArrayList<String>();
                int i = 0;
                for(Expense number : arrayList){
                    list.add(number.getName());
                    Log.d("expense name", number.getName());
                }

                cs = list.toArray(new CharSequence[list.size()]);
                builder1.setItems(cs,new DialogInterface.OnClickListener(){

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        name = (String) cs[which];
                        Log.d("expense selected", (String)cs[which]);
                        element=which;
                        for(Expense number : arrayList) {
                            if (arrayList.get(element).getName().equals((String)cs[which])) {
                                expense=arrayList.get(element);
                                selectedElement = expense;
                                name=expense.getName();
                                date=expense.getDate();
                                amount=expense.getAmount();
                                Log.d("expense details",name+date+amount);
                                editText = (EditText) findViewById(R.id.editactivity_name);
                                editText.setText(name);//expense.getName());
                                editText = (EditText) findViewById(R.id.editactivity_amount);
                                editText.setText(amount+"");//expense.getAmount() + "");
                                editText = (EditText) findViewById(R.id.editactivity_date);
                                editText.setText(date);//expense.getDate());
                                date = expense.getDate();
                                Toast.makeText(Edit_activity.this, "Image: " + expense.getImageURI(), Toast.LENGTH_SHORT).show();

                                /*imageReceipt = (ImageView) findViewById(R.id.imagereciept_editactivity);
                                Uri imageURI = Uri.parse(expense.getImageURI());
                                Picasso.with(Edit_activity.this)
                                        .load(expense.getImageURI())
                                        .into(imageReceipt);

                                imageReceipt.getLayoutParams().height = 60;

                                imageReceipt.getLayoutParams().width = 60;

                                imageReceipt.setScaleType(ImageView.ScaleType.FIT_XY);*/

                                int index = 0;
                                for (int i = 0; i < category_spinner.getCount(); i++) {
                                    if (category_spinner.getItemAtPosition(i).toString().equalsIgnoreCase(expense.getCategories())) {
                                        index = i;
                                        break;
                                    }
                                }
                                category_spinner.setSelection(index);
                            }
                        }
                    }
                }
                );
                final AlertDialog alert = builder1.create();
                alert.show();
            }
        });

        imageView =(ImageView) findViewById(R.id.imagedate_editactivity);
        imageView.setOnClickListener(new View.OnClickListener(){
                                         @Override
                                         public void onClick(View v) {
                                             setDateField();
                                         }
                                     }
        );

        imageView = (ImageView) findViewById(R.id.imagereciept_editactivity);
        imageView.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 Intent gallery = new Intent(
                         Intent.ACTION_PICK,
                         android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
                 startActivityForResult(gallery, SELECT_IMAGE);
             }
         });
        buttonSave = (Button) findViewById(R.id.button_save);
        buttonSave.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                int flag=1;
                AlertDialog.Builder builder = new AlertDialog.Builder(Edit_activity.this);
                EditText editText = (EditText) findViewById(R.id.editactivity_name);
                if(editText.getText().toString().length()<=50 && editText.getText().toString().length()>0 ) {
                    name = editText.getText().toString();
                    flag=0;
                }
                else{
                    flag=1;
                    builder.setTitle("Enter Name").setMessage("Name should be entered");
                    AlertDialog alert = builder.create();
                    alert.show();
                }

                editText =(EditText) findViewById(R.id.editactivity_amount);
                String amount_entered = editText.getText().toString();
                if(amount_entered.equals(null)){
                    flag=1;
                    builder.setTitle("Enter amount").setMessage("Amount should contain Numbers only");
                    AlertDialog alert = builder.create();
                    alert.show();
                }else{
                    amount=Double.parseDouble(amount_entered);
                    flag=0;

                }
                if(image_path.equals("")){
                    flag=1;
                    builder.setTitle("Pic a image").setMessage("Select an image of the receipt");
                    AlertDialog alert = builder.create();
                    alert.show();
                }else{
                    flag=0;
                }
                if(date.equals(null)){
                    flag=1;
                    builder.setTitle("Enter a date").setMessage("Select a Date");
                    AlertDialog alert = builder.create();
                    alert.show();
                }else{
                    flag=0;
                }
                category=category_spinner.getSelectedItem().toString();
                if(category.equals("Select a Category")){
                    flag=1;
                    builder.setTitle("Pic a Category").setMessage("Select a category");
                    AlertDialog alert = builder.create();
                    alert.show();
                }else{
                    flag=0;
                }

                if(flag==0){
                    Expense expense = new Expense(name,category,amount,date,image_path);
                    arrayList.remove(selectedElement);
                    arrayList.add(element,expense);
                    Intent explicitIntent = new Intent(Edit_activity.this,MainActivity.class);
                    explicitIntent.putExtra(MainActivity.ACTION_KEY,MainActivity.EDIT_KEY);
                    explicitIntent.putExtra(MainActivity.EXPENSELIST_KEY,arrayList);
                    startActivity(explicitIntent);
                }
            }
        });
        button = (Button)findViewById(R.id.button_cancel);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent explicitIntent = new Intent(Edit_activity.this,MainActivity.class);
                explicitIntent.putExtra(MainActivity.ACTION_KEY,MainActivity.EDIT_KEY);
                explicitIntent.putExtra(MainActivity.EXPENSELIST_KEY,arrayList);
                startActivity(explicitIntent);
            }
        });
    }
    private void setDateField() {
        Calendar newCalendar = Calendar.getInstance();
        datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                editText.setText(dateFormatter.format(newDate.getTime()));
                date = dateFormatter.format(newDate.getTime());
            }

        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));

        datePickerDialog.show();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode==RESULT_OK && requestCode==SELECT_IMAGE){
            Uri selectedImage=data.getData();
            String path=getPath(selectedImage);
            image_path = path;
            Toast.makeText(Edit_activity.this, "Image here:" +expense.getImageURI(), Toast.LENGTH_SHORT).show();
            ImageView imageView= (ImageView) findViewById(R.id.imagereciept_editactivity);
            Picasso.with(Edit_activity.this)
                    .load(expense.getImageURI())
                    .into(imageView);
            imageView.getLayoutParams().height = 60;

            imageView.getLayoutParams().width = 60;

            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
        }
    }

    public String getPath(Uri uri){
        String[] filePathColumn={MediaStore.Images.Media.DATA};

        Cursor cursor=getContentResolver().query(uri, filePathColumn, null, null, null);
        cursor.moveToFirst();
        int columnIndex=cursor.getColumnIndex(filePathColumn[0]);

        return cursor.getString(columnIndex);
    }
}
