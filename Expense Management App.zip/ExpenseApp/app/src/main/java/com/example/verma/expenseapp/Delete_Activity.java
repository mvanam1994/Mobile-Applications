package com.example.verma.expenseapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class Delete_Activity extends AppCompatActivity {

    private ArrayList<Expense> arrayList;
    Button button;
    Button buttonCancel;
    Expense expense;
    CharSequence[] cs;
    EditText editText;
    ImageView imageView;
    Spinner category_spinner;
    String name;
    String date;
    int element;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_);
        if (getIntent().getExtras() != null) {
            arrayList = (ArrayList) getIntent().getExtras().get(MainActivity.EXPENSELIST_KEY);
        }
        category_spinner = (Spinner) findViewById(R.id.spinner_delete_category);
        String[] items = new String[]{"Select a Category","Groceries", "Invoice", "Transportation", "Rent", "Trips", "Utilities", "Others"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items);
        category_spinner.setAdapter(adapter);

        button = (Button) findViewById(R.id.button_select_delete);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder1= new AlertDialog.Builder(Delete_Activity.this);
                builder1.setTitle("Pick an Expense");
                List<String> list = new ArrayList<String>();
                int i = 0;
                for(Expense number : arrayList){
                    list.add(number.getName());
                    Log.d("expense name", number.getName());
                }

                cs = list.toArray(new CharSequence[list.size()]);
                builder1.setItems(cs,new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                name = (String) cs[which];
                                Log.d("which",which+"");
                                element=which;
                                expense=arrayList.get(element);
                                editText=(EditText)findViewById(R.id.edit_delete_name);
                                editText.setText(expense.getName());
                                editText.setEnabled(false);
                                editText=(EditText)findViewById(R.id.edit_delete_amount);
                                editText.setText(expense.getAmount()+"");
                                editText.setEnabled(false);
                                editText=(EditText)findViewById(R.id.edit_delete_date);
                                editText.setText(expense.getDate());
                                date=expense.getDate();
                                editText.setEnabled(false);

                                imageView = (ImageView) findViewById(R.id.image_delete_receipt);
                               // Picasso.with(Delete_Activity.this)
                               //         .load(expense.getImageURI())
                               //         .into(imageView);

                                int index=0;
                                for (int i = 0; i<category_spinner.getCount(); i++){
                                    if (category_spinner.getItemAtPosition(i).toString().equalsIgnoreCase(expense.getCategories())){
                                        index = i;
                                        break;
                                    }
                                }
                                category_spinner.setSelection(index);
                                category_spinner.setEnabled(false);
                            }
                        }
                );
                final AlertDialog alert = builder1.create();
                alert.show();
                element=0;



            }
        });
        buttonCancel = (Button)findViewById(R.id.button_delete_cancel);
        buttonCancel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent explicitIntent = new Intent(Delete_Activity.this,MainActivity.class);
                explicitIntent.putExtra(MainActivity.EXPENSELIST_KEY,arrayList);
                explicitIntent.putExtra(MainActivity.ACTION_KEY,"Delete Cancel");
                startActivity(explicitIntent);
            }
        });

        button = (Button) findViewById(R.id.button_delete);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                arrayList.remove(element);
                Intent explicitIntent = new Intent(Delete_Activity.this,MainActivity.class);
                explicitIntent.putExtra(MainActivity.ACTION_KEY,MainActivity.DELETE_KEY);
                explicitIntent.putExtra(MainActivity.EXPENSELIST_KEY,arrayList);
                startActivity(explicitIntent);
            }
        });


    }

}
