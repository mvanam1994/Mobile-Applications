package com.example.verma.expenseapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    final static String EXPENSE_KEY = "expense";
    final static String EXPENSELIST_KEY= "expenseList";
    final static String ACTION_KEY="action";
    final static String ADD_KEY = "add";
    final static String EDIT_KEY = "edit";
    final static String DELETE_KEY = "delete";
    final static String SHOW_KEY = "show";
    final static String ELEMENT_KEY="element";
    private ArrayList<Expense> expenseList;
    Expense expense;
    String action;
    int position;
    int placement=0;
    int flag=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        expenseList = new ArrayList();
        Button addButton = (Button) findViewById(R.id.add_button);
        Button showButton = (Button) findViewById(R.id.show_button);
        Button editButton = (Button) findViewById(R.id.edit_button);
        Button deleteButton = (Button) findViewById(R.id.delete_button);
        Button finishButton = (Button) findViewById(R.id.finish_button);

        if (getIntent().getExtras() != null) {
            action=(String )getIntent().getExtras().get(ACTION_KEY);
            if(action.equals(ADD_KEY)){
                expenseList=(ArrayList<Expense>) getIntent().getExtras().get(EXPENSELIST_KEY);
            }else if(action.equals(DELETE_KEY)){
                expenseList=(ArrayList<Expense>) getIntent().getExtras().get(EXPENSELIST_KEY);
            }else if(action.equals(EDIT_KEY)) {
                expenseList = (ArrayList<Expense>) getIntent().getExtras().get(EXPENSELIST_KEY);
            }else if(action.equals(SHOW_KEY)) {
                expenseList = (ArrayList<Expense>) getIntent().getExtras().get(EXPENSELIST_KEY);
            }
            else if(action.equals("Delete Cancel")) {
                expenseList = (ArrayList<Expense>) getIntent().getExtras().get(EXPENSELIST_KEY);
            }
        }

        addButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent explicitIntent = new Intent(MainActivity.this, Add_Activity.class);
                explicitIntent.putExtra(EXPENSELIST_KEY,expenseList);
                startActivity(explicitIntent);
            }
        });

        editButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent explicitIntent = new Intent(MainActivity.this, Edit_activity.class);
                explicitIntent.putExtra(EXPENSELIST_KEY,expenseList);
                startActivity(explicitIntent);
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent explicitIntent = new Intent(MainActivity.this, Delete_Activity.class);
                explicitIntent.putExtra(EXPENSELIST_KEY,expenseList);
                startActivity(explicitIntent);
            }
        });

        showButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(expenseList.size()!=0) {
                    Intent explicitIntent = new Intent(MainActivity.this, Show_Activity.class);
                    explicitIntent.putExtra(EXPENSELIST_KEY, expenseList);
                    startActivity(explicitIntent);
                }
                else{
                    Toast.makeText(MainActivity.this,"List is empty",Toast.LENGTH_LONG).show();
                }
            }
        });

        finishButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

}
