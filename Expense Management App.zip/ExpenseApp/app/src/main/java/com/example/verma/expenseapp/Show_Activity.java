
        package com.example.verma.expenseapp;

        import android.content.Intent;
        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.util.Log;
        import android.view.View;
        import android.widget.Button;
        import android.widget.ImageButton;
        import android.widget.ImageView;
        import android.widget.TextView;

        import com.squareup.picasso.Picasso;

        import java.util.ArrayList;

public class Show_Activity extends AppCompatActivity {
    private ArrayList<Expense> arrayList;
    Button button;
    Expense expense;
    TextView editText;
    ImageButton imageView;
    ImageView imageView1;
    String name;
    String date;
    int element=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_);
        if (getIntent().getExtras() != null) {
            arrayList = (ArrayList) getIntent().getExtras().get(MainActivity.EXPENSELIST_KEY);
        }
        display(element);
        imageView = (ImageButton) findViewById(R.id.imageView_first);
        imageView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                display(0);
            }
        });
        imageView = (ImageButton) findViewById(R.id.imageView_next);
        imageView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                element++;
                Log.d("position",element+"");
                if(element>=arrayList.size()) {
                    element--;
                    display(element);
                }else{
                    display(element);
                }
            }
        });
        imageView = (ImageButton) findViewById(R.id.imageView_last);
        imageView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                display(arrayList.size()-1);
            }
        });
        imageView = (ImageButton) findViewById(R.id.imageView_prev);
        imageView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                element--;
                Log.d("position",element+"");
                if(element<0) {
                    element++;
                    display(element);
                }else{
                    display(element);
                }
            }
        });
        button = (Button) findViewById(R.id.button_show_finish);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent explicitIntent = new Intent(Show_Activity.this,MainActivity.class);
                explicitIntent.putExtra(MainActivity.ACTION_KEY,MainActivity.EDIT_KEY);
                explicitIntent.putExtra(MainActivity.EXPENSELIST_KEY,arrayList);
                startActivity(explicitIntent);
            }
        });


    }
    public void display(int postion){
        Log.d("position",postion+"");
        expense = arrayList.get(postion);
        editText = (TextView) findViewById(R.id.textView_show_name);
        editText.setText(expense.getName());
        editText.setEnabled(false);
        editText = (TextView) findViewById(R.id.textView_show_amount);
        editText.setText(expense.getAmount() + "");
        editText.setEnabled(false);
        editText = (TextView) findViewById(R.id.textView_show_date);
        editText.setText(expense.getDate());
        editText.setEnabled(false);
        editText = (TextView) findViewById(R.id.textView_show_category);
        editText.setText(expense.getCategories());


        imageView1 = (ImageView) findViewById(R.id.imageView_show_reciept);
        Picasso.with(Show_Activity.this)
                .load(expense.getImageURI())
                .into(imageView1);

    }
}
