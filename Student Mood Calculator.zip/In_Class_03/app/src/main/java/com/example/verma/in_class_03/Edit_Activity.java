package com.example.verma.in_class_03;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

public class Edit_Activity extends AppCompatActivity {

    private static Student student;
    private static EditText nameText;
    private static EditText emailText;
    private static RadioGroup departmentGroup;
    private static SeekBar moodBar;
    private static TextView yourMood;
    private static String action="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_);
        if(getIntent().getExtras()!=null){
            action = getIntent().getExtras().getString("Action");
            student = (Student) getIntent().getExtras().getSerializable(MainActivity.STUDENT_KEY);
            nameText = (EditText) findViewById(R.id.editText_name3);
            nameText.setText(student.name);
            emailText = (EditText) findViewById(R.id.editText2_email3);
            emailText.setText(student.emailAddress);
            departmentGroup = (RadioGroup) findViewById(R.id.radioGroup3);
            String id = student.department;
            RadioButton selected = (RadioButton) findViewById(R.id.SIS2);
            if(selected.getText().equals(id)){
                selected.setChecked(true);
            }
            selected = (RadioButton) findViewById(R.id.CS2);
            if(selected.getText().equals(id)){
                selected.setChecked(true);
            }
            selected = (RadioButton) findViewById(R.id.BIO2);
            if(selected.getText().equals(id)){
                selected.setChecked(true);
            }
            selected = (RadioButton) findViewById(R.id.Others3);
            if(selected.getText().equals(id)){
                selected.setChecked(true);
            }
            moodBar = (SeekBar) findViewById(R.id.seek_mood3) ;
            moodBar.setProgress(student.mood);


        }
        if(action.equals("Name")){
            emailText = (EditText) findViewById(R.id.editText2_email3);
            emailText.setVisibility(View.INVISIBLE);
            departmentGroup = (RadioGroup) findViewById(R.id.radioGroup3);
            departmentGroup.setVisibility(View.INVISIBLE);
            moodBar = (SeekBar) findViewById(R.id.seek_mood3) ;
            moodBar.setVisibility(View.INVISIBLE);
            yourMood = (TextView) findViewById(R.id.moodStat3) ;
            yourMood.setVisibility(View.INVISIBLE);

        }
        else if(action.equals("Email")){
            nameText = (EditText) findViewById(R.id.editText_name3);
            nameText.setVisibility(View.INVISIBLE);
            departmentGroup = (RadioGroup) findViewById(R.id.radioGroup3);
            departmentGroup.setVisibility(View.INVISIBLE);
            moodBar = (SeekBar) findViewById(R.id.seek_mood3) ;
            moodBar.setVisibility(View.INVISIBLE);
            yourMood = (TextView) findViewById(R.id.moodStat3) ;
            yourMood.setVisibility(View.INVISIBLE);
        }
        else if(action.equals("Department")){
            emailText = (EditText) findViewById(R.id.editText2_email3);
            emailText.setVisibility(View.INVISIBLE);
            nameText = (EditText) findViewById(R.id.editText_name3);
            nameText.setVisibility(View.INVISIBLE);
            moodBar = (SeekBar) findViewById(R.id.seek_mood3) ;
            moodBar.setVisibility(View.INVISIBLE);
            yourMood = (TextView) findViewById(R.id.moodStat3) ;
            yourMood.setVisibility(View.INVISIBLE);
        }
        else if(action.equals("Mood")){
            emailText = (EditText) findViewById(R.id.editText2_email3);
            emailText.setVisibility(View.INVISIBLE);
            nameText = (EditText) findViewById(R.id.editText_name3);
            nameText.setVisibility(View.INVISIBLE);
            departmentGroup = (RadioGroup) findViewById(R.id.radioGroup3);
            departmentGroup.setVisibility(View.INVISIBLE);
        }
        Button save = (Button) findViewById(R.id.button_save);
        save.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(action.equals("Name")){
                    nameText = (EditText) findViewById(R.id.editText_name3);
                    student.setName(nameText.getText().toString());
                }
                else if(action.equals("Email")) {
                    emailText = (EditText) findViewById(R.id.editText2_email3);
                    student.setEmailAddress(emailText.getText().toString());
                }
                else if(action.equals("Department")) {
                    departmentGroup = (RadioGroup) findViewById(R.id.radioGroup3);
                    RadioButton radioButton = (RadioButton) findViewById(departmentGroup.getCheckedRadioButtonId());
                    String dept = radioButton.getText().toString();
                    student.setDepartment(dept);
                }
                else if(action.equals("Mood")) {
                    moodBar = (SeekBar) findViewById(R.id.seek_mood3);
                    student.setMood(moodBar.getProgress());
                }
                Intent explicitIntent = new Intent(Edit_Activity.this,Display.class);
                explicitIntent.putExtra(MainActivity.STUDENT_KEY,student);
                startActivity(explicitIntent);
            }
        });
    }
}
