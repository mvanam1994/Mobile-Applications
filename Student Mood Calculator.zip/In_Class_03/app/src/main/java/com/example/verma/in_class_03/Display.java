package com.example.verma.in_class_03;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class Display extends AppCompatActivity {

    private static Student student;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        if(getIntent().getExtras()!=null){
            student = (Student) getIntent().getExtras().getSerializable(MainActivity.STUDENT_KEY);
            TextView textView = (TextView) findViewById(R.id.name_text);
            textView.setText(student.name+"");
            textView = (TextView) findViewById(R.id.email_text);
            textView.setText(student.emailAddress+"");
            textView = (TextView) findViewById(R.id.department_text);
            textView.setText(student.department+"");
            textView = (TextView) findViewById(R.id.mood_text);
            textView.setText(student.mood+" % Positive");
        }
        findViewById(R.id.imageView).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent implicitIntent = new Intent("com.example.verma.in_class_03.intent.action.VIEW");
                implicitIntent.addCategory(Intent.CATEGORY_DEFAULT);
                implicitIntent.putExtra("Action","Name");
                implicitIntent.putExtra(MainActivity.STUDENT_KEY,student);
                startActivity(implicitIntent);
            }
        });
        findViewById(R.id.imageView2).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent implicitIntent = new Intent("com.example.verma.in_class_03.intent.action.VIEW");
                implicitIntent.addCategory(Intent.CATEGORY_DEFAULT);
                implicitIntent.putExtra("Action","Email");
                implicitIntent.putExtra(MainActivity.STUDENT_KEY,student);
                startActivity(implicitIntent);
            }
        });
        findViewById(R.id.imageView3).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent implicitIntent = new Intent("com.example.verma.in_class_03.intent.action.VIEW");
                implicitIntent.addCategory(Intent.CATEGORY_DEFAULT);
                implicitIntent.putExtra("Action","Department");
                implicitIntent.putExtra(MainActivity.STUDENT_KEY,student);
                startActivity(implicitIntent);
            }
        });
        findViewById(R.id.imageView4).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent implicitIntent = new Intent("com.example.verma.in_class_03.intent.action.VIEW");
                implicitIntent.addCategory(Intent.CATEGORY_DEFAULT);
                implicitIntent.putExtra("Action","Mood");
                implicitIntent.putExtra(MainActivity.STUDENT_KEY,student);
                startActivity(implicitIntent);
            }
        });
    }
}
