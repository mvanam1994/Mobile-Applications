package com.example.verma.in_class_03;

import java.io.Serializable;

/**
 * Created by verma on 9/6/2016.
 */
public class Student implements Serializable {

    /*Student class consisting of five variables: name, email address,
department, account state, and mood*/
    String name;
    String emailAddress;
    String department;
    int mood;

    public Student(String name, String emailAddress, String department, int mood) {
        this.name = name;
        this.emailAddress = emailAddress;
        this.department = department;
        this.mood = mood;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", emailAddress='" + emailAddress + '\'' +
                ", Department='" + department + '\''  +
                ", mood=" + mood +
                '}';
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setMood(int mood) {
        this.mood = mood;
    }

}
