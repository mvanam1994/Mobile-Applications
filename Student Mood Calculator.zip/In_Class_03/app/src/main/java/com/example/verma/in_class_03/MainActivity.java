package com.example.verma.in_class_03;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    final static String STUDENT_KEY = "STUDENT";
    private String dept="";
    private RadioGroup department;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.button_submit).setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                String name="";
                String email="";

                int mood=-99;
                EditText name_text = (EditText) findViewById(R.id.edit_name);
                name=name_text.getText().toString();
                Log.d("Name",name);

                EditText email_text = (EditText) findViewById(R.id.edit_email);
                email=email_text.getText().toString();
                Log.d("Email",email);

                department = (RadioGroup) findViewById(R.id.radioGroup);
                department.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){
                    @Override
                    public void onCheckedChanged(RadioGroup group, int checkedId) {
                        RadioButton radioButton = (RadioButton) findViewById(department.getCheckedRadioButtonId());
                        dept=radioButton.getText().toString();
                        Log.d("Department", dept);
                    }
                });


                SeekBar seekMood = (SeekBar) findViewById(R.id.seekBar);
                mood=seekMood.getProgress();
                Log.d("Seek Bar",mood+"");
                if(name.equals("")){
                    Toast.makeText(MainActivity.this,"Please enter name", Toast.LENGTH_LONG).show();
                }
                else if(email.equals("")){
                    Toast.makeText(MainActivity.this,"Please enter email", Toast.LENGTH_LONG).show();
                }
                else if(dept.equals("")){
                    Toast.makeText(MainActivity.this,"Please select a department", Toast.LENGTH_LONG).show();
                } else if (mood == -99) {
                    Toast.makeText(MainActivity.this,"Please set mood", Toast.LENGTH_LONG).show();
                }
                else {
                    Student student = new Student(name, email, dept, mood);
                    Intent explicitIntent = new Intent(MainActivity.this, Display.class);
                    explicitIntent.putExtra(STUDENT_KEY, student);
                    startActivity(explicitIntent);
                }
            }
        });
    }
}
